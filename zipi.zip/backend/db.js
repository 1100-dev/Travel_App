// //File: db.js in root directory
 
// import myMongoose from 'mongoose';
 
// // Saving my MongoDB URI
// const mongoURL = 'mongodb://localhost:27017/pakistan_explorer_db';
 
// // Creating a function to connect to MongoDB
// const connectToMongo = async () => {
//     try {
//         await myMongoose.connect(mongoURL);
//         console.log('Connected to MongoDB');
//     } catch (e) {
//         console.error('Error connecting to MongoDB:', e.message);
//     }
// };
// export default connectToMongo;
import mongoose from "mongoose";

const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log("MongoDB connected");
  } catch (error) {
    console.error(error);
    process.exit(1);
  }
};

export default connectDB;
