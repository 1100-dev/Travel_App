import Booking from "../models/Booking.js";
import User from "../models/User.js";

export const createBooking = async (req, res) => {
  try {
    const { userId, destination, packageName, fullName, email, phone, address } = req.body;

    const user = await User.findById(userId);
    if (!user)
      return res.json({ success: false, message: "User not logged in" });

    const booking = new Booking({
      userId,
      destination,
      package: packageName,
      fullName,
      email,
      phone,
      address
    });

    await booking.save();
    res.json({ success: true, message: "Booking confirmed", booking });

  } catch (error) {
    res.status(500).json({ success: false, message: "Server error" });
  }
};

export const getUserBookings = async (req, res) => {
  try {
    const bookings = await Booking.find({ userId: req.params.userId });
    res.json(bookings);
  } catch (error) {
    res.status(500).json({ message: "Server error" });
  }
};
